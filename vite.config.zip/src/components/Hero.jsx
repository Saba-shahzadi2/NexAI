import heroImage from "../assets/photo-1551288049-bebda4e38f71.avif";
import { useNavigate } from "react-router-dom";

const Hero = () => {
  const navigate = useNavigate();
  return (
    <section className="bg-gray-50 dark:bg-gray-900 dark:text-white transition-colors duration-300">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center px-8 py-20 max-w-6xl mx-auto rounded-lg">
        {/* Left Side (Content) */}
        <div data-aos="fade-right" className="max-w-lg flex flex-col gap-6">
          <h1 className="text-5xl font-extrabold leading-tight tracking-tight text-gray-900 dark:text-white">
            AI-Powered Solutions for{" "}
            <span className="text-blue-600 dark:text-blue-400">
              Modern Businesses
            </span>
          </h1>

          <p className="text-lg text-gray-600 dark:text-gray-300 leading-relaxed">
            Streamline workflows, automate repetitive tasks, and boost
            productivity with the power of artificial intelligence.
          </p>

          <div data-aos="zoom-in" data-aos-delay="400">
            <button onClick={() => navigate("/register")}>Get Started</button>
          </div>
        </div>

        {/* Right Side (Professional AI/Tech Image) */}
        <div
          data-aos="fade-left"
          data-aos-delay="300"
          className="w-full flex items-center justify-center relative"
        >
          {/* Subtle decorative glowing background blur effect */}
          <div className="absolute top-0 right-0 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>

          <img
            src={heroImage}
            alt="NexAI Dashboard Interface"
            className="w-full h-auto rounded-2xl shadow-2xl border border-gray-200/50 dark:border-gray-700/30 object-cover transform hover:scale-[1.02] transition-transform duration-500 relative z-10"
          />
        </div>
      </div>
    </section>
  );
};

export default Hero;
