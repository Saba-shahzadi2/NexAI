import { useState, useEffect } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { SiNotion } from "react-icons/si";
import { FaSun, FaMoon, FaBars, FaTimes } from "react-icons/fa";
import { useTheme } from "../context/ThemeContext";
import { motion, AnimatePresence } from "framer-motion";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { darkMode, setDarkMode } = useTheme();
  const navigate = useNavigate();

  const navItems = [
    { to: "/", label: "Home" },
    { to: "/features", label: "Features" },
    { to: "/pricing", label: "Pricing" },
    { to: "/about", label: "About" },
    { to: "/contact", label: "Contact" },
  ];

  // Scroll effect (blur + shrink)
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Body scroll lock
  useEffect(() => {
    document.body.style.overflow = isOpen ? "hidden" : "";
  }, [isOpen]);

  const navLinkClass = ({ isActive }) =>
    `relative transition font-medium ${
      isActive
        ? "text-blue-600 dark:text-blue-400"
        : "text-gray-700 dark:text-gray-200 hover:text-blue-500"
    }`;

  return (
    <nav
      className={`fixed w-full z-50 transition-all duration-300 ${
        scrolled
          ? "bg-white/70 dark:bg-gray-900/70 backdrop-blur-lg shadow-md"
          : "bg-white/90 dark:bg-gray-900/90"
      }`}
    >
      <div className="max-w-7xl mx-auto h-16 px-6 flex items-center justify-between">
        {/* Logo */}
        <NavLink to="/" className="flex items-center gap-2 text-blue-600">
          <SiNotion size={32} />
          <span className="text-2xl font-bold">NexAI</span>
        </NavLink>

        {/* Desktop Links */}
        <div className="hidden md:flex items-center gap-8">
          {navItems.map((item) => (
            <NavLink key={item.to} to={item.to} className={navLinkClass}>
              {item.label}
              <span className="block h-[2px] w-0 bg-blue-500 transition-all group-hover:w-full"></span>
            </NavLink>
          ))}
        </div>

        {/* Desktop Actions */}
        <div className="hidden md:flex items-center gap-4">
          <button
            onClick={() => setDarkMode((p) => !p)}
            className="p-2 rounded-lg text-xl hover:bg-gray-100 dark:hover:bg-gray-800"
          >
            {darkMode ? <FaSun className="text-amber-400" /> : <FaMoon />}
          </button>

          <button
            onClick={() => navigate("/login")}
            className="px-4 py-2 border rounded-xl hover:border-blue-500 dark:text-white boarder-gray-700 dark:border-gray-300"
          >
            Login
          </button>

          <button
            onClick={() => navigate("/register")}
            className="px-4 py-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700"
          >
            Get Started
          </button>
        </div>

        {/* Mobile Controls */}
        <div className="md:hidden flex items-center gap-3">
          <button onClick={() => setDarkMode((p) => !p)}>
            {darkMode ? (
              <FaSun className="dark:text-amber-400" />
            ) : (
              <FaMoon className="dark:text-white" />
            )}
          </button>

          <button onClick={() => setIsOpen(true)}>
            <FaBars className="dark:text-white" size={22} />
          </button>
        </div>
      </div>

      {/* MOBILE MENU */}
      <AnimatePresence>
        {isOpen && (
          <>
            {/* Overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="fixed inset-0 bg-black/40 z-40"
            />

            {/* Slide Menu */}
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ duration: 0.3 }}
              className="fixed top-0 right-0 w-72 h-full bg-white dark:bg-gray-900 z-50 shadow-xl p-6"
            >
              {/* Close */}
              <button onClick={() => setIsOpen(false)} className="mb-6 text-xl">
                <FaTimes />
              </button>

              {/* Links */}
              <div className="flex flex-col gap-5">
                {navItems.map((item) => (
                  <NavLink
                    key={item.to}
                    to={item.to}
                    onClick={() => setIsOpen(false)}
                    className={navLinkClass}
                  >
                    {item.label}
                  </NavLink>
                ))}
              </div>

              {/* Actions */}
              <div className="mt-8 flex flex-col gap-3">
                <button
                  onClick={() => navigate("/login")}
                  className="border py-2 rounded-xl"
                >
                  Login
                </button>

                <button
                  onClick={() => {
                    navigate("/register");
                    setIsOpen(false);
                  }}
                  className="bg-blue-600 text-white py-2 rounded-xl"
                >
                  Get Started
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;
